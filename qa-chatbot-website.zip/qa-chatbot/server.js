import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const port = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "The assistant is not connected yet. Add your OpenAI API key to the .env file, then restart the server." });
    }

    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const safeMessages = messages
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20)
      .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are QA chatbot, a professional personal AI assistant. Answer clearly and accurately. Help with questions and everyday tasks such as planning, drafting, organizing, and explaining. Use the conversation history for context. If a request is ambiguous, ask one concise clarifying question. Do not claim to have performed real-world actions unless a connected tool actually performed them."
        },
        ...safeMessages
      ],
      temperature: 0.5
    });

    res.json({ reply: response.choices[0]?.message?.content || "I couldn't generate a response. Please try again." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Something went wrong while generating a reply. Check the server logs and API configuration." });
  }
});

app.listen(port, () => console.log(`QA chatbot is running at http://localhost:${port}`));
