# QA chatbot

A responsive website for a professional personal AI assistant. It answers questions, uses recent conversation history as context, and helps with everyday tasks.

## Requirements

- Node.js 18 or newer
- An OpenAI API key

## Run locally

1. Extract the ZIP and open a terminal in the `qa-chatbot` folder.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env` and add your API key:

   ```env
   OPENAI_API_KEY=your_api_key_here
   PORT=3000
   ```

4. Start the website:

   ```bash
   npm start
   ```

5. Open http://localhost:3000 in your browser.

## Included

- Responsive chat interface
- Professional assistant instructions
- Conversation context sent with each request (latest 20 messages)
- Quick prompts for planning, explanations, writing, and task organization
- New conversation and clear chat controls

## Important notes

- The API key stays on the server; do not put it in browser JavaScript or commit `.env`.
- Conversation context is held in the current browser tab's memory and is not saved permanently. Reloading or starting a new chat clears it.
- This starter does not connect to calendars, email, reminders, or other external services. The assistant can help plan and draft, but cannot perform those actions without integrations.
- Before public deployment, add authentication, rate limiting, usage limits, and privacy disclosures. Review the hosting provider's secret-management instructions.
